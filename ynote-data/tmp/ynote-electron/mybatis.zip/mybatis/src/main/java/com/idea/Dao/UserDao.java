package com.idea.Dao;

import com.idea.domain.User;

import java.util.List;

/*
@author lts
@create 2021-02-06-16:34
usage 
*/
public interface UserDao{
    List<User> findAll();
}
